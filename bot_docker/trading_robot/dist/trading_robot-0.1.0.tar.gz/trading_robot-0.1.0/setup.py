# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['trading_robot']

package_data = \
{'': ['*']}

install_requires = \
['mysql-connector-python>=8.0.23,<9.0.0',
 'numpy>=1.20.1,<2.0.0',
 'openapi-client @ '
 'git+https://github.com/andreiandreeev/deribit_cloned.git@master',
 'robot>=20071211,<20071212',
 'start>=0.2,<0.3']

setup_kwargs = {
    'name': 'trading-robot',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
